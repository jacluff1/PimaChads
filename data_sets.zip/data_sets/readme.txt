clean.csv: 	the whole data set
train.csv: 	obvious
validate.csv: 	obvious
test.csv:	obvious
